import os
import asyncio
import requests
import logging
import shutil
from configparser import ConfigParser
from datetime import datetime, timedelta
import base64  # Import base64 module
import os


# Load configuration
config = ConfigParser()
config.read('config.ini')
hospital_name = config.get('DEFAULT', 'hospitalName')
tmp_folder_count = config.getint('DEFAULT', 'tmpFolderCount')
sql_file_size_limit = config.getint('DATABASE', 'sqlFileSizeLimit')
# New entry to get the base64 encoded link
get = config.get('DEFAULT', 'get')
post = config.get('DEFAULT', 'post')

def decode_get(encoded_data):
    """Decode double encoded internet checking get string.   https://radiolims.sigmentech.com  """
    try:
        decoded_data = base64.b64decode(encoded_data)
        decoded_data = base64.b64decode(decoded_data)
        return decoded_data
    except Exception as e:
        logging.error("Error decoding get data: {}".format(e))
        return None
def decode_post(encoded_data):
    """Decode double encoded api post string.    https://sigma.pacs.sigmentech.com/studies   """
    try:
        decoded_data = base64.b64decode(encoded_data)
        decoded_data = base64.b64decode(decoded_data)
        return decoded_data
    except Exception as e:
        logging.error("Error decoding post data: {}".format(e))
        return None
    
# Encode Sample function
# def encode_data(data):
#     """Encode data using base64."""
#     try:
#         encoded_data = base64.b64encode(data.encode('utf-8'))
#         encoded_data = base64.b64encode(encoded_data)
#         print(encoded_data)
#         return encoded_data
#     except Exception as e:
#         logging.error("Error encoding data: {}".format(e))
#         return None

# Decode the base64 link
get_link = decode_get(get).decode('utf-8')
post_link = decode_post(post).decode('utf-8')

# New database connection details from config
try:
    table_name = config.get('DATABASE', 'table_name')

except Exception as e:
    logging.error("Error loading database configuration: {}".format(e))
    raise  # Re-raise the exception to stop the application if critical

log_file_path = os.path.join(os.path.dirname(__file__), 'logs.txt')
error_data_path = os.path.join(os.path.dirname(__file__), 'error_data')
temp_data_path = os.path.join(os.path.dirname(__file__), 'temp_data')
sql_backup_path = os.path.join(os.path.dirname(__file__), 'sql_backup')

logging.basicConfig(filename=log_file_path, level=logging.INFO)

data_folder_path = os.path.join(os.path.dirname(__file__), 'data')

async def main():

    # Start the move_back_from_error_data task
    # Run this in the background
    asyncio.ensure_future(move_back_from_error_data())
    # Run the temp folder limit check in the background
    asyncio.ensure_future(check_temp_folder_limit())

    while True:
        try:
            # Print the start of the data folder check
            print("Checking for new files in data folder...")
            print(f"Data folder path: {data_folder_path}")  # Print the path being checked
            all_files = os.listdir(data_folder_path)  # List all files and folders
            print(f"Contents of data folder: {all_files}")  # Print the contents of the folder
            
            folders = [f for f in all_files if os.path.isdir(os.path.join(data_folder_path, f))]
            # Print the folders found
            print(f"Folders found: {folders}")

            if not folders:
                await asyncio.sleep(60)
                continue

            for folder in folders:
                folder_path = os.path.join(data_folder_path, folder)
                # Print the folder being processed
                print(f"Processing folder: {folder}")
                # Check for subfolders within the current folder
                subfolders = [f for f in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, f))]
                for subfolder in subfolders:
                    subfolder_path = os.path.join(folder_path, subfolder)
                    if any(os.listdir(subfolder_path)):  # Check if the subfolder is not empty
                        # Move the subfolder to the data directory
                        new_location = os.path.join(data_folder_path, subfolder)
                        shutil.move(subfolder_path, new_location)
                        # logging.info(f"Moved folder {subfolder} to {data_folder_path}")
                        # print(f"Moved folder {subfolder} to {data_folder_path}")

                # Remove the original folder if it's empty after moving subfolders
                if not any(os.listdir(folder_path)):  # Check if the folder is now empty
                    shutil.rmtree(folder_path)
                    logging.info("Removed empty folder: {}".format(folder_path))
                    print("Removed empty folder: {}".format(folder_path))

                # print(f"Processing folder: {folder}")
                files = sorted(get_dcm_file_paths(folder_path),
                               key=lambda f: os.path.getctime(f))
                print("Files found (sorted by creation time): {}".format(files))

                if not files:
                    # print("No files found in folder, skipping...")
                    continue

                # Open files and store file handles
                file_handles = []
                folder_moved = False  # Flag to track if the folder has been moved
                try:
                    # Include folder name
                    post_data = {'file': [(open(file, 'rb'), file)
                                          for file in files], 'folder_name': folder}
                    # Store file handles
                    file_handles = [fh[0] for fh in post_data['file']]
                    # print("Checking internet connection...")
                    has_internet_access = await is_connected()
                    print("Internet access: {}".format(has_internet_access))

                    if has_internet_access:
                        # Print the upload attempt
                        print(f"Uploading studies from folder: {folder}")
                        successful_files, failed_files = await upload_studies(post_data)
                        # Print the results of the upload
                        print(f"Successful uploads: {successful_files}")
                        print(f"Failed uploads: {failed_files}")

                        # Only create a unique folder in temp_data if there are successful uploads
                        if successful_files:
                            new_folder_path = os.path.join(temp_data_path, folder)
                            # Ensure the folder exists
                            os.makedirs(new_folder_path, exist_ok=True)

                            # Move successful files to temp_data
                            for file_name in successful_files:
                                original_file_path = os.path.join(folder_path, file_name)
                                move_dcm_folder(
                                    original_file_path, new_folder_path)

                        # Only move the folder to error_data if there are failed uploads
                        if failed_files:
                            # Move failed files to error_data
                            for file_name in failed_files:
                                original_file_path = os.path.join(folder_path, file_name)
                                move_to_error_data(original_file_path)
                            # Move the entire folder to error_data if there were any failed uploads
                            move_to_error_data(folder_path)
                            folder_moved = True  # Set the flag to true

                    else:
                        logging.error("No Internet Access!!")
                        print("No internet access, sleeping for 5 seconds...")
                        await asyncio.sleep(5)
                except Exception as e:
                    logging.error("Error during processing: {}".format(e))
                    if not folder_moved:  # Move to error_data only if not already moved
                        move_to_error_data(folder_path)
                        folder_moved = True  # Set the flag to true
                finally:
                    # Ensure all file handles are closed
                    for fh in file_handles:
                        fh.close()

                    # Check if the folder still exists before moving
                    if os.path.exists(folder_path) and not folder_moved:
                        # If the folder was not moved due to errors, we can delete it
                        shutil.rmtree(folder_path)  # Delete the original folder
                        logging.info("Original folder deleted: {}".format(folder_path))
                        # print(f"Original folder deleted: {folder_path}")
        except Exception as e:
            print("Error in Try file {}".format(e))


async def upload_studies(post_data):
    successful_files = []
    failed_files = []
    try:
        # print("Sending POST request to upload studies...")

        # Correctly format the files parameter
        files = {os.path.basename(file_path): file_handle for file_handle, file_path in post_data['file']}

        # Log the files being sent
        # print(f"Files being uploaded: {list(files.keys())}")

        # Create a list to hold the upload tasks
        upload_tasks = []

        for file_name, file_handle in files.items():
            upload_tasks.append(upload_file(
                # Create upload tasks
                file_name, file_handle, post_data['folder_name'], successful_files, failed_files))

        # Limit concurrent uploads to 4
        for i in range(0, len(upload_tasks), 4):
            # Upload 4 files at a time
            await asyncio.gather(*upload_tasks[i:i + 4])


    finally:
        # Ensure all file handles are closed
        for file_handle in post_data['file']:
            try:
                file_handle[0].close()  # Close the file handle correctly
            except Exception as e:
                logging.error("Error closing file {}: {}".format(file_handle[1], e))

    return successful_files, failed_files


async def upload_file(file_name, file_handle, folder_name, successful_files, failed_files):
    try:
        response = requests.post(
            post_link,
            files={file_name: file_handle},
            headers={'next_api': 'CALL_PHP_API',
                     'hospital_name': hospital_name}
        )
        response.raise_for_status()
        successful_files.append(file_name)  # Track successful uploads
        logging.info("Upload Success for {}".format(file_name))
        print("Upload successful for: {}".format(file_name))

        # Access the patient name from the folder name
        patient_name = folder_name  # Use folder name as patient name
        if patient_name:
            # Prepare SQL for successful upload
            upload_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            sql_file_path = os.path.join(sql_backup_path, 'record.sql')
            
            # Check if the record.sql file size exceeds the limit from config
            if os.path.exists(sql_file_path) and os.path.getsize(sql_file_path) >= sql_file_size_limit * 1024 * 1024:
                # Rename the existing record.sql file with the current date
                new_sql_file_name = "record_{}.sql".format(datetime.now().strftime('%Y%m%d'))
                new_sql_file_path = os.path.join(sql_backup_path, new_sql_file_name)
                os.rename(sql_file_path, new_sql_file_path)  # Rename the file
                logging.info("Renamed SQL file to: {}".format(new_sql_file_path))
                print("Renamed SQL file to: {}".format(new_sql_file_path))

            # Write to the new record.sql file
            with open(sql_file_path, 'a') as sql_file:
                sql_file.write("INSERT INTO {} (patient_name, hospital_name, upload_time, status_flag, error_time, image_name) VALUES ('{}', '{}', '{}', 'T', NULL, '{}');\n".format(table_name, patient_name, hospital_name, upload_time, file_name))
            print("Upload recorded in SQL file for patient: {}".format(patient_name))

    except requests.exceptions.HTTPError as err:
        logging.error("HTTP error occurred for {}: {}".format(file_name, err))
        print("HTTP error occurred for {}: {}".format(file_name, err))
        failed_files.append(file_name)  # Track failed uploads
        # Prepare SQL for failed upload
        patient_name = folder_name  # Use folder name as patient name
        if patient_name:
            upload_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            error_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            sql_file_path = os.path.join(sql_backup_path, 'record.sql')
            
            # Check if the record.sql file size exceeds the limit from config
            if os.path.exists(sql_file_path) and os.path.getsize(sql_file_path) >= sql_file_size_limit * 1024 * 1024:
                # Rename the existing record.sql file with the current date
                new_sql_file_name = "record_{}.sql".format(datetime.now().strftime('%Y%m%d'))
                new_sql_file_path = os.path.join(sql_backup_path, new_sql_file_name)
                os.rename(sql_file_path, new_sql_file_path)  # Rename the file
                logging.info("Renamed SQL file to: {}".format(new_sql_file_path))
                print("Renamed SQL file to: {}".format(new_sql_file_path))

            # Write to the new record.sql file
            with open(sql_file_path, 'a') as sql_file:
                sql_file.write("INSERT INTO {} (patient_name, hospital_name, upload_time, status_flag, error_time, image_name) VALUES ('{}', '{}', NULL, 'H', '{}', '{}');\n".format(table_name, patient_name, hospital_name, error_time, file_name))
            print("Failed upload recorded in SQL file for patient: {}".format(patient_name))

    except Exception as err:
        logging.error("Other error occurred for {}: {}".format(file_name, err))
        print("Other error occurred for {}: {}".format(file_name, err))
        failed_files.append(file_name)  # Track failed uploads
        # Prepare SQL for failed upload
        patient_name = folder_name  # Use folder name as patient name
        if patient_name:
            upload_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            error_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            sql_file_path = os.path.join(sql_backup_path, 'record.sql')
            
            # Check if the record.sql file size exceeds the limit from config
            if os.path.exists(sql_file_path) and os.path.getsize(sql_file_path) >= sql_file_size_limit * 1024 * 1024:
                # Rename the existing record.sql file with the current date
                new_sql_file_name = "record_{}.sql".format(datetime.now().strftime('%Y%m%d'))
                new_sql_file_path = os.path.join(sql_backup_path, new_sql_file_name)
                os.rename(sql_file_path, new_sql_file_path)  # Rename the file
                logging.info("Renamed SQL file to: {}".format(new_sql_file_path))
                print("Renamed SQL file to: {}".format(new_sql_file_path))

            # Write to the new record.sql file
            with open(sql_file_path, 'a') as sql_file:
                sql_file.write("INSERT INTO {} (patient_name, hospital_name, upload_time, status_flag, error_time, image_name) VALUES ('{}', '{}', NULL, 'F', '{}', '{}');\n".format(table_name, patient_name, hospital_name, error_time, file_name))
            print("Failed upload recorded in SQL file for patient: {}".format(patient_name))


async def move_back_from_error_data():
    while True:  # Keep this running indefinitely
        print("Checking if error_data_path exists...")
        if os.path.exists(error_data_path):
            # print(f"Iterating over folders in: {error_data_path}")
            for error_folder in os.listdir(error_data_path):
                error_folder_path = os.path.join(error_data_path, error_folder)
                if os.path.isdir(error_folder_path):
                    print("Found directory: {}".format(error_folder_path))

                    # Move the folder back to the data directory
                    data_folder_path = error_folder_path.replace('error_data', 'data')
                    print("Preparing to move folder to: {}".format(data_folder_path))

                    # Check if the destination folder exists
                    if os.path.exists(data_folder_path):
                        # If it exists, merge files from error_folder to data_folder_path
                        for error_file in os.listdir(error_folder_path):
                            error_file_path = os.path.join(error_folder_path, error_file)
                            if os.path.isfile(error_file_path):
                                destination_file = os.path.join(data_folder_path, error_file)
                                if not os.path.exists(destination_file):  # Only move if the file doesn't exist
                                    print("Moving file: {} to {}".format(error_file_path, data_folder_path))
                                    shutil.move(error_file_path, destination_file)
                                    logging.info("Moved file back to data: {}".format(destination_file))
                                    print("Moved file back to data: {}".format(destination_file))
                                else:
                                    print("File already exists in destination: {}, skipping move.".format(destination_file))

                        # After merging, check if the error folder is empty before removing it
                        if not any(os.listdir(error_folder_path)):  # Check if the folder is empty
                            shutil.rmtree(error_folder_path)
                            logging.info("Removed empty error folder: {}".format(error_folder_path))
                            print("Removed empty error folder: {}".format(error_folder_path))
                    else:
                        print("Moving folder: {} to {}".format(error_folder_path, data_folder_path))
                        shutil.move(error_folder_path, data_folder_path)
                        logging.info("Moved folder back to data: {}".format(data_folder_path))
                        print("Moved folder back to data: {}".format(data_folder_path))
        else:
            print("Error data path does not exist.")

        await asyncio.sleep(120)  # Sleep for 120 seconds before checking again


async def check_temp_folder_limit():
    while True:
        try:
            # Check the number of folders in temp_data
            temp_folders = sorted(os.listdir(temp_data_path),
                                  key=lambda f: os.path.getctime(os.path.join(temp_data_path, f)))
            if len(temp_folders) >= tmp_folder_count:  # Check if the limit is reached
                # Calculate how many folders to remove
                # +1 to remove extra the oldest
                folders_to_remove = len(temp_folders) - tmp_folder_count + 0
                for folder in temp_folders[:folders_to_remove]:
                    folder_path = os.path.join(temp_data_path, folder)
                    shutil.rmtree(folder_path)  # Remove the oldest folder
                    logging.info("Removed old folder: {}".format(folder_path))
                    print("Removed old folder: {}".format(folder_path))

        except Exception as e:
            logging.error("Error checking temp folder limit: {}".format(e))
            print("Error checking temp folder limit: {}".format(e))

        await asyncio.sleep(600)  # Sleep for 10 minutes (600 seconds)


def get_dcm_file_paths(folder):
    # print(f"Getting DCM file paths in folder: {folder}")
    all_files = []
    for root, dirs, files in os.walk(folder):
        for file in files:
            all_files.append(os.path.join(root, file))
    # print(f"DCM files found: {all_files}")
    return all_files


def move_dcm_folder(old_path, new_path):
    # print(f"Moving DCM folder from {old_path} to {new_path}")
    if not os.path.exists(temp_data_path):
        os.makedirs(temp_data_path)

    try:
        # Check if the old path is a directory
        if os.path.isdir(old_path):
            # Move the entire directory structure to the new path
            for root, dirs, files in os.walk(old_path):
                # Create corresponding subdirectories in new path
                rel_path = os.path.relpath(root, old_path)
                new_dir = os.path.join(new_path, rel_path)
                os.makedirs(new_dir, exist_ok=True)

                # Move each file while preserving directory structure
                for file in files:
                    old_file = os.path.join(root, file)
                    new_file = os.path.join(new_dir, file)
                    shutil.move(old_file, new_file)
                    logging.info("File moved, old path: {}, new path: {}".format(old_file, new_file))
                    print("File moved to temp_data: {}".format(new_file))

            # Remove original directory after moving all contents
            shutil.rmtree(old_path)
            logging.info("Original directory removed: {}".format(old_path))
        else:
            # Move single file to the new path
            shutil.move(old_path, os.path.join(new_path, os.path.basename(old_path)))
            logging.info("File moved, old path: {}, new path: {}".format(old_path, os.path.join(new_path, os.path.basename(old_path))))
            print("File moved to temp_data: {}".format(os.path.join(new_path, os.path.basename(old_path))))
    except Exception as e:
        logging.error("Error moving file from {} to {}: {}".format(old_path, new_path, e))
        print("Error moving file: {}".format(e))


def move_to_error_data(folder):
    print("Moving folder to error_data: {}".format(folder))
    if not os.path.exists(error_data_path):
        os.makedirs(error_data_path)

    error_folder_path = str(folder).replace('data', 'error_data')

    # Check if the destination path already exists
    if os.path.exists(error_folder_path):
        # Remove the existing folder to replace it
        shutil.rmtree(error_folder_path)
        logging.info("Existing error folder deleted: {}".format(error_folder_path))
        print("Existing error folder deleted: {}".format(error_folder_path))

    # Move the new folder to error_data
    shutil.move(folder, error_folder_path)
    logging.info("Folder moved to error_data, old path: {}, new path: {}".format(folder, error_folder_path))
    print("Folder moved to error_data: {}".format(error_folder_path))

    # Ensure the original folder is deleted only if it still exists
    if os.path.exists(folder):
        shutil.rmtree(folder)  # Delete the original folder
        logging.info("Original folder deleted: {}".format(folder))
        print("Original folder deleted: {}".format(folder))


async def is_connected():
    try:
        print("Checking connection to the decoded link...")
        # Use get_link in the request
        requests.get(get_link, timeout=5)
        print("Internet connection is available.")
        return True
    except requests.ConnectionError:
        print("No internet connection.")
        return False


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
